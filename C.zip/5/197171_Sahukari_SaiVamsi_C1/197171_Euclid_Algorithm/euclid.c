#include<gmp.h>
#include<stdio.h>
void main()
{
	mpz_t a,b,c;
	mpz_inits(a,b,c,NULL);
	gmp_printf("\n Enter the value of a -");
	gmp_scanf("%Zd",a);
	gmp_printf("\n Enter the value of b -");
	gmp_scanf("%Zd",b);
	while(mpz_cmp_ui(b,0)!=0)
	{
		mpz_set(c,b);
		mpz_mod(b,a,b);
		mpz_set(a,c);
		
	}
	gmp_printf("\n GCD of (a,b) is - %Zd",a);
	gmp_printf("\n");
}
