#include<gmp.h>
#include<stdio.h>
void main()
{
	mpz_t a,b,c;
	mpz_inits(a,b,c,NULL);
	gmp_printf("\n Enter a- ");
	gmp_scanf("%Zd",a);
	gmp_printf("\n Enter b- ");
	gmp_scanf("%Zd",b);
	mpz_add(c,a,b);
	gmp_printf("\n a+b=%Zd",c);
	mpz_sub(c,a,b);
	gmp_printf("\n a-b=%Zd",c);
	mpz_mul(c,a,b);
	gmp_printf("\n a*b=%Zd",c);
	mpz_fdiv_q(c,a,b);
	gmp_printf("\n a/b=%Zd",c);
	mpz_mod(c,a,b);
	gmp_printf("\n a%b=%Zd",c);
	gmp_printf("\n");
}
