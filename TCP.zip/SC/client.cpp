#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/wait.h>
#include <arpa/inet.h>
#include <bits/stdc++.h>
using namespace std;

#define PORT 8080
int main(int argc, char const *argv[]){
	
	int sfd;
	struct sockaddr_in address;
	
	if ((sfd= socket(AF_INET, SOCK_STREAM, 0)) < 0) { 
		printf("\n Socket creation error \n"); 
		return -1; 
	} 

	address.sin_family = AF_INET; 
	address.sin_port = htons(PORT); 
	
	// Convert IPv4 and IPv6 addresses from text to binary form 
	if(inet_pton(AF_INET, "127.0.0.1", &address.sin_addr)<=0){ 
		printf("\nInvalid address/ Address not supported \n"); 
		return -1; 
	} 

	if (connect(sfd, (struct sockaddr *)&address, sizeof(address)) < 0) { 
		printf("\nConnection Failed \n"); 
		return -1; 
	} 
	
	
	struct sockaddr_in addr;
    	socklen_t len = sizeof(addr);
    	getsockname(sfd, (struct sockaddr*) &addr, &len);
    	printf("Local IP address: %s\n", inet_ntoa(addr.sin_addr));
	printf("Local port no   : %d\n", ntohs(addr.sin_port));
	
	//getpeername(nsfd,struct sockaddr *addr,socklen_t *alenp);
    	getpeername(sfd, (struct sockaddr*) &addr, &len);
    	printf("Foreign IP address: %s\n", inet_ntoa(addr.sin_addr));
	printf("Foreign port no   : %d\n", ntohs(addr.sin_port));
	
	char input[100];
	cout<<"Enter :";
	cin.getline(input,100);
	send(sfd, input, strlen(input), 0);

    return 0;
 }
