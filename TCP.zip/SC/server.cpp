#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/wait.h>
#include <arpa/inet.h>
#include <bits/stdc++.h>
using namespace std;

#define PORT 8080
int main(int argc, char const *argv[]){
	
	int sfd,nsfd;
	int opt=1;
	int rec;
	struct sockaddr_in address;
	int addrlen = sizeof(address);
	
	//Creating sfd
	if( (sfd = socket(AF_INET, SOCK_STREAM, 0)) == 0 ){
		perror("socket failed");
		exit(EXIT_FAILURE);
	}
	
	//Attaching to the port if already in use
	if (setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))){
        	perror("setsockopt");
        	exit(EXIT_FAILURE);
    	}
    	
    	//Setting address
    	address.sin_family = AF_INET;
    	address.sin_port = htons(PORT);
    	address.sin_addr.s_addr = INADDR_ANY;  //local address
    	
    	
    	//Binding to port
    	if((bind(sfd, (struct sockaddr *)&address,sizeof(address)) == -1)){
    		perror("bind failed");
    		exit(EXIT_FAILURE);
    	}
    	
    	
    	//getsockname(sfd,struct sockaddr_in *addr,socklen_t *alenp)
    	struct sockaddr_in addr;
    	socklen_t len = sizeof(addr);
    	getsockname(sfd, (struct sockaddr*) &addr, &len);
    	printf("Local IP address: %s\n", inet_ntoa(addr.sin_addr));
	printf("Local port no   : %d\n", ntohs(addr.sin_port));
    	
    	while(true){
  
    		//listen()
    		if( (listen(sfd,5) == -1 )){
    			perror("listen");
    			exit(EXIT_FAILURE);
    		}
  	
  		
    		//accept()
    		if((nsfd = accept(sfd, (struct sockaddr *)&address,(socklen_t*)&addrlen)) == -1){
    			perror("accept failure");
    			exit(EXIT_FAILURE);
    		}
    	
    	
    		//getpeername(nsfd,struct sockaddr *addr,socklen_t *alenp);
   	 	getpeername(nsfd, (struct sockaddr*) &addr, &len);
    		printf("Foreign IP address: %s\n", inet_ntoa(addr.sin_addr));
		printf("Foreign port no   : %d\n", ntohs(addr.sin_port));
	
	
		char buffer[1024] = {0};
       	 //close(sfd);
       	rec = recv(nsfd, buffer, 1024, 0);
        	cout<<"Sent by Client: "<<buffer<<"\n\n";
        	close(nsfd);
        }
        
       
   return 0;
}
       
    	
    	
	
